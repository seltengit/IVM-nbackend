<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Delivery;
use App\Models\LineItem;

class DeliveryController extends Controller
{
    public function index()
    {
        return response()->json(Delivery::with('lineItems')->get(), 200);
    }

    public function show($id)
    {
        $delivery = Delivery::with('lineItems')->find($id);

        if (!$delivery) {
            return response()->json(['message' => 'Delivery not found'], 404);
        }

        return response()->json($delivery, 200);
    }

    public function store(Request $request)
    {
        $request->validate([
            'customer_name' => 'required|string',
            'customer_address' => 'required|string',
            'customer_phone' => 'required|string',
            'driver_name' => 'required|string',
            'driver_vehicle_no' => 'required|string',
            'driver_phone' => 'required|string',
            'lineitems' => 'required|array|min:1',
            'lineitems.*.product_name' => 'required|string',
            'lineitems.*.product_code' => 'required|string',
            'lineitems.*.quantity_required' => 'required|integer',
            'lineitems.*.quantity_delivered' => 'required|integer',
        ]);

        $delivery = Delivery::create($request->only([
            'customer_name',
            'customer_address',
            'customer_phone',
            'driver_name',
            'driver_vehicle_no',
            'driver_phone'
        ]));

        // ✅ Bulk Insert for better performance
        LineItem::insert(
            array_map(fn($item) => array_merge($item, ['delivery_id' => $delivery->id]), $request->lineitems)
        );

        return response()->json([
            'message' => 'Delivery created successfully',
            'delivery' => $delivery->load('lineItems')
        ], 201);
    }

    public function update(Request $request, $id)
    {
        $delivery = Delivery::find($id);

        if (!$delivery) {
            return response()->json(['message' => 'Delivery not found'], 404);
        }

        $delivery->update($request->only([
            'customer_name',
            'customer_address',
            'customer_phone',
            'driver_name',
            'driver_vehicle_no',
            'driver_phone'
        ]));

        return response()->json([
            'message' => 'Delivery updated successfully',
            'delivery' => $delivery->load('lineItems')
        ], 200);
    }

    public function destroy($id)
    {
        $delivery = Delivery::find($id);

        if (!$delivery) {
            return response()->json(['message' => 'Delivery not found'], 404);
        }

        $delivery->delete();

        return response()->json(['message' => 'Delivery deleted successfully'], 200);
    }
}
